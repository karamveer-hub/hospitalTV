let url='https://docs.google.com/spreadsheets/d/1iVfL4zRlxN7Sxs4z69Uz0wP-0rGN1YAdUg0i0uiuO9A/export?format=csv'

async function data(){
    await fetch(url).then(result => result.text()).then(csvtext=> {
         csv().fromString(csvtext).then(final=>htmlfunction(final));
    })
}
data()

let displayDataElement=document.querySelector('.third_div')
function htmlfunction(data){
    // console.log(data)
    let string=" ";
    for (let i = 0; i < data.length; i++) {
      string+=` <div class="display_flex">
      <p>${data[i].s_no}</p>
      <p>${data[i].UHID}</p>
      <p>${data[i].name}</p>
      <p>${data[i].contact}</p>
      <p>${data[i].address}</p>
  </div>`
    }
    displayDataElement.innerHTML=string;

}